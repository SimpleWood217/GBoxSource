<?php

// // 示例代码
// $config = array(
//     'public_key'  => "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDKSfeZm8x3oxTtgsBe5G1LrnMF\n09HtSewWOqeEdEGgsC9AT9aA/LtmxaxsnzIxMtIZSiDWPz9AmWyMMWczAo2AVqao\npVq7070xSIdx4wx9LNJPhKC8RvBpIrZjETSN0aw1glXppU5HM/wPUTQ+OniLyOjN\n2Cg4b0b4sVy7wcsM/QIDAQAB\n-----END PUBLIC KEY-----"
// );

// $rsa = new RSA($config);
// $en = $rsa->encryptByPublicKey('test');

// echo $en . "\n";

class RSA {

    var $publicKey;
    var $privateKey;

    public function __construct($config) {
        if (isset($config['public_key'])) {
            $this->publicKey = $config['public_key'];
        }
        if (isset($config['private_key'])) {
            $this->privateKey = $config['private_key'];
        }
        if (!$this->publicKey && !$this->privateKey) {
            throw new Exception('请配置公钥或私钥');
        }
    }

    private function urlsafe_b64encode($string) {
        $data = base64_encode($string);
        return $data;
    }
    
    private function urlsafe_b64decode($string) {
        return base64_decode($string);
    }
    
    public function encryptByPublicKey($string) {
        $crypto = '';
        foreach (str_split($string, 117) as $chunk) {
            $pub = $this->publicKey;
            openssl_public_encrypt($chunk, $encryptData, $pub);
            $crypto .= $encryptData;
        }
        return $this->urlsafe_b64encode($crypto);
    }

    public function decryptByPublicKey($string) {
        $crypto = '';
        foreach (str_split($this->urlsafe_b64decode($string), 128) as $chunk) {
            openssl_public_decrypt($chunk, $decryptData, $this->publicKey);
            $crypto .= $decryptData;
        }
        return $crypto;
    }

    public function encryptByPrivateKey($string) {
        $crypto = '';
        foreach (str_split($string, 117) as $chunk) {
            openssl_private_encrypt($chunk, $encryptData, $this->privateKey);
            $crypto .= $encryptData;
        }
        return $this->urlsafe_b64encode($crypto);
    }
    
    public function decryptByPrivateKey($string) {
        $crypto = '';
        foreach (str_split($this->urlsafe_b64decode($string), 128) as $chunk) {
            openssl_private_decrypt($chunk, $decryptData, $this->privateKey);
            $crypto .= $decryptData;
        }
        return $crypto;
    }
}
