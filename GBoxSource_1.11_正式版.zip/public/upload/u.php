<?php
/*
 * 上传图片接口 date:2023-12-10 admin:SimpleWood
 */
header("Access-Control-Allow-Origin: *"); // 解决跨域
header('Access-Control-Allow-Methods: POST'); // 响应类型
date_default_timezone_set('PRC'); // 获取当前时间

// 上传文件目录
$month = date('Ym', time());
define('BASE_PATH', str_replace('\\', '/', realpath(dirname(__FILE__) . '/')) . "/");
$dir = "image/" . $month . "/";

// 初始化返回数组
$arr = array('code' => 0, 'msg' => '', 'file' => '');

if (!isset($_FILES['file'])) {
    $arr['msg'] = '没有选择上传文件';
    echo json_encode($arr);
    exit();
}

$file_info = $_FILES['file'];
$file_error = $file_info['error'];

if (!is_dir($dir)) {
    if (!mkdir($dir, 0777, true)) {
        $arr['msg'] = '创建目录失败';
        echo json_encode($arr);
        exit();
    }
}

$houzhui = '';
if ($file_info["type"] == "image/jpeg") {
    $houzhui = "jpeg";
} elseif ($file_info["type"] == "image/png") {
    $houzhui = "png";
} elseif ($file_info["type"] == "image/jpg" || $file_info["type"] == "image/jpeg") {
    $houzhui = "jpg";
} else {
    $arr['msg'] = '不支持的文件类型';
    echo json_encode($arr);
    exit();
}

$file_name = $dir . date('YmdHis') . '.' . $houzhui;
if (!file_exists($file_name)) {
    if ($file_error == 0) {
        if (move_uploaded_file($file_info["tmp_name"], $file_name)) {
            // 验证文件是否有效
            if (is_readable($file_name) && filesize($file_name) > 0) {
                $arr['file'] = $file_name;
                $arr['code'] = 'success';
                $arr['msg'] = '文件上传成功，路径：' . $file_name;
            } else {
                $arr['msg'] = '上传的文件无效或已损坏';
                unlink($file_name); // 删除损坏的文件
            }
        } else {
            $arr['msg'] = "上传失败";
        }
    } else {
        switch ($file_error) {
            case 1:
                $arr['msg'] = '上传文件超过了PHP配置文件中upload_max_filesize选项的值';
                break;
            case 2:
                $arr['msg'] = '超过了表单max_file_size限制的大小';
                break;
            case 3:
                $arr['msg'] = '文件部分被上传';
                break;
            case 4:
                $arr['msg'] = '没有选择上传文件';
                break;
            case 6:
                $arr['msg'] = '没有找到临时文件';
                break;
            case 7:
            case 8:
                $arr['msg'] = '系统错误';
                break;
        }
    }
} else {
    $arr['code'] = "1";
    $arr['msg'] = "当前目录中，文件" . $file_name . "已存在";
}

echo json_encode($arr);
