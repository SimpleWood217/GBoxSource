<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
    function smtp($address, $name, $body)
    {
        /*
         Name：SMTP发信服务
         Date：2022-12-14
         Author：Muster
         */
        include_once EXTEND_PATH . 'class.phpmailer.php';
        $mail = new \PHPMailer();
        $mail->IsSMTP();
        $mail->Host = 'smtp.163.com';
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'ssl';
        $mail->Username = 'simplewoodnetwork@163.com';   //账号
        $mail->Password = 'UPFEAAPTXUXYEPXB';    //密码
        $mail->Port = 465;
        $mail->From = 'simplewoodnetwork@163.com'; //这个必须和账号相同
        $mail->FromName = 'KS底包';
        $mail->AddAddress($address, $address); //收件人
        $mail->Subject = $name;
        $mail->Body = $body;
        $mail->CharSet = 'UTF-8';
        $mail->ContentType = 'text/html; charset=UTF-8';
        $mail->Send();
    }