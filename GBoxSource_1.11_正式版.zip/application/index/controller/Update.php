<?php

    namespace app\index\controller;

    use think\Controller;
    use think\view;
    use think\Db;
    use think\Route;
    use think\request;
    use think\Cookie;
    use think\Session;

    class Update extends Controller
    {
        public function index()
        {
            $this->login_state();
            //获取当前版本
            $version = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/../version.txt');
            //获取最新版本
            $new_version = file_get_contents("https://www.jm217.cn/gbox.php/new_ver");
            //比对版本
            if($version == $new_version) {
                return ['code'=>'false','reason'=>'当前已是最新版本！'];
            }
            
            // 定义更新文件的 URL 和本地保存路径
            $updateFileUrl = "https://www.jm217.cn/gbox/$new_version.zip";
            $localUpdateFilePath = $_SERVER['DOCUMENT_ROOT']."/../update.zip";
            //下载更新压缩包
            file_put_contents($localUpdateFilePath, fopen($updateFileUrl, 'r'));
            // 解压更新压缩包
            $zip = new \ZipArchive();
            if ($zip->open($localUpdateFilePath) === TRUE) {
                $zip->extractTo($_SERVER['DOCUMENT_ROOT'].'/../');
                $zip->close();
                $data['file'] = '成功';
            } else {
                $data['file'] = '失败';
            }
            // 检查是否需要更新数据库
            $isSqlUpdate = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/../is_sql_update.txt');
            if ($isSqlUpdate == '1') {
                // 读取 SQL 文件内容
                $sqlFilePath = $_SERVER['DOCUMENT_ROOT'].'/../sql.txt';
                $sql = file_get_contents($sqlFilePath);
                // 使用分号分隔 SQL 语句
                $sqlStatements = explode(';', $sql);
                $s=0;$f=0;
                // 遍历执行每个 SQL 语句
                foreach ($sqlStatements as $sqlStatement) {
                    // 去除可能存在的空白字符
                    $sqlStatement = trim($sqlStatement);
                    
                    if (!empty($sqlStatement)) { // 如果 SQL 语句不为空
                        // 执行 SQL 更新操作
                        $result = Db::execute($sqlStatement);
                        if ($result !== false) {
                            $s=$s+1;
                        } else {
                            $f=$f+1;
                        }
                    }
                }
                // echo "SQL语句成功执行 $s 条，失败 $f 条<br>";
                $data['sql'] = "数据库SQL语句成功执行 $s 条，失败 $f 条";
            } else {
                $data['sql'] = "数据库无需更新";
            }
            // 删除更新文件
            unlink($_SERVER['DOCUMENT_ROOT'].'/../is_sql_update.txt');
            unlink($_SERVER['DOCUMENT_ROOT'].'/../sql.txt');
            unlink($_SERVER['DOCUMENT_ROOT'].'/../update.zip');
            Cookie::delete('code');
            $data['code'] = 'success';
            return $data;
        }
        
        
        /*
        * 检查登录状态
        */
        private function login_state()
        {
            $code = Cookie::get('code');
            $date = date('Ymd');
            $ip = request()->ip();
            $user = base64_decode(Cookie::get('code2'));
            if($code != md5($date.$ip.$user)) {
                exit("<script>window.location.href='".url('login')."'</script>");
            }
        }
    }
