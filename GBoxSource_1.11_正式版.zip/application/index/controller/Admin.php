<?php

    namespace app\index\controller;

    use think\Controller;
    use think\view;
    use think\Db;
    use think\Route;
    use think\request;
    use think\Cookie;
    use think\Session;

    class Admin extends Controller
    {
        /*
        * 首页
        */
        public function index()
        {
            $this->login_state();
            $b = file_get_contents('https://www.jm217.cn/gbox.php/i');
            if($b != 'true') exit($b);
            $this->assign('username',Db::table('gbox_admin')->where('id=1')->value('username'));
            return view();
        }
        
        /*
        * 控制台
        */
        public function console()
        {
            $this->login_state();
            $version = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/../version.txt');
            $forceUpdate = file_get_contents('https://www.jm217.cn/gbox.php/forceUpdate?version='.$version);
            if($forceUpdate == 'true') exit('<script>top.location.href="'.url('forceUpdate').'"</script>');
            
            $info['cpuCores'] = $this->getCpuCores();
            $info['MemorySize'] = $this->getServerMemorySize();
            $info['System'] = $this->getSystem();
            $result = Db::query('SELECT version() as version');
            $info['mysqlVersion'] = $result[0]['version'];
            $info['serverEngine'] = $_SERVER['SERVER_SOFTWARE'];
            
            $data['sourceNumber'] = Db::table('gbox_source')->count();
            $data['appNumber'] = Db::table('gbox_app')->count();
            
            $data['pukAllNumber'] = Db::table('gbox_puk')->count();
            $data['pukUseNumber'] = Db::table('gbox_puk')->where('state=1')->count();
            
            $data['todayUnlock'] = Db::table('gbox_puk')->where(['useDate'=>date('Y-m-d'),'state'=>1])->count();
            $data['yestrdayUnlock'] = Db::table('gbox_puk')->where(['useDate'=>date('Y-m-d',strtotime('-1 day')),'state'=>1])->count();
            
            $this->assign('data',$data);
            $this->assign('info',$info);
            $this->assign('update_log',file_get_contents("https://www.jm217.cn/gbox.php/update_log"));
            $this->assign('faq',file_get_contents("https://www.jm217.cn/gbox.php/faq"));
            return view();
        }
        
        /*
        * 源列表
        */
        public function sourceList()
        {
            $this->login_state();
            $data = parse_url(request()->url(true));
            if(empty($data['query'])) $data['query'] = '';
            $this->assign('url',$data['query']);
            return view();
        }
        
        /*
        * 创建源
        */
        public function creatSource()
        {
            $this->login_state();
            return view();
        }
        
        /*
        * 应用列表
        */
        public function appList()
        {
            $this->login_state();
            $data = parse_url(request()->url(true));
            if(empty($data['query'])) $data['query'] = '';
            $source_list = Db::table('gbox_source')->select();
            $this->assign('url',$data['query']);
            $this->assign('source',$source_list);
            return view();
        }
        
        /*
        * 解锁码列表
        */
        public function pukList()
        {
            $this->login_state();
            $data = parse_url(request()->url(true));
            if(empty($data['query'])) $data['query'] = '';
            $puk_list = Db::table('gbox_puk')->select();
            $source_list = Db::table('gbox_source')->select();
            $this->assign('source',$source_list);
            $this->assign('url',$data['query']);
            $this->assign('puk',$puk_list);
            return view();
        }
        
        /*
        * 黑名单列表
        */
        public function blockList()
        {
            $this->login_state();
            $data = parse_url(request()->url(true));
            if(empty($data['query'])) $data['query'] = '';
            $block_list = Db::table('gbox_block')->select();
            $this->assign('url',$data['query']);
            $this->assign('puk',$block_list);
            return view();
        }
        
        /*
        * 生成解锁码
        */
        public function creatPuk()
        {
            $this->login_state();
            $source = Db::table('gbox_source')->select();
            $this->assign('source',$source);
            return view();
        }
        
        /*
        * 创建APP
        */
        public function creatApp()
        {
            $this->login_state();
            $source = Db::table('gbox_source')->select();
            $this->assign('source',$source);
            return view();
        }
        
        /*
        * 修改源
        */
        public function editSource()
        {
            $this->login_state();
            $get = request()->get();
            if(empty($get['id'])) exit('error');
            $data = Db::table('gbox_source')->where(['id'=>$get['id']])->find();
            if(empty($data)) exit('error');
            $this->assign('data',$data);
            return view();
        }
        
        /*
        * 修改源
        */
        public function editApp()
        {
            $this->login_state();
            $get = request()->get();
            if(empty($get['id'])) exit('error');
            $data = Db::table('gbox_app')->where(['id'=>$get['id']])->find();
            if(empty($data)) exit('error');
            $source = Db::table('gbox_source')->select();
            
            $sort = Db::table('gbox_source')->where(['id'=>$data['belongTo']])->value('sort');
            $html=$belongTo_html='';
            $i=$n=0;
            $cateindex = $data['cateindex'];
            $sort = explode('|',$sort);
            foreach ($sort as $arr) {
                if($i==$cateindex){
                    $html .= '<option selected value="'.$i.'">'.$arr.'</option>';
                } else {
                    $html .= '<option value="'.$i.'">'.$arr.'</option>';
                }
                $i++;
            }
            foreach ($source as $arr2) {
                $n++;
                if($n==$data['belongTo']) {
                    $belongTo_html .= '<option selected value="'.$n.'">'.$arr2['name'].'</option>';
                } else {
                    $belongTo_html .= '<option value="'.$n.'">'.$arr2['name'].'</option>';
                }
            }
            
            $this->assign('belongTo_html',$belongTo_html);
            $this->assign('cateindex',$html);
            $this->assign('source',$source);
            $this->assign('data',$data);
            return view();
        }
        
        public function editPwd()
        {
            $this->login_state();
            $username = Db::table('gbox_admin')->where('id=1')->value('username');
            $this->assign('username',$username);
            return view();
        }
        
        public function login()
        {
            return view();
        }
        
        public function update()
        {
            $this->login_state();
            //获取当前系统版本
            $version = file_get_contents($_SERVER['DOCUMENT_ROOT'].'/../version.txt');
            //获取最新版本
            $new_version = file_get_contents("https://www.jm217.cn/gbox.php/new_ver");
            //比对版本
            if($version == $new_version) {
                $data['msg'] = '当前已经是最新版本';
            } elseif ($version < $new_version) {
                $data['msg'] = '发现新版本！<a style="color:blue" onclick="update()">立即更新</a>';
            }
            $data['version'] = $version;
            $data['new_version'] = $new_version;
            $data['update_log'] = file_get_contents("https://www.jm217.cn/gbox.php/update_log");
            $this->assign('data',$data);
            return view();
        }
        
        /*
        * 后端接口
        */
        public function ajax()
        {
            $submit = request()->post();
            if(empty($submit)) $submit = request()->get();
            $mod = $submit['mod'];
            switch($mod) {
                case 'login':
                    if($submit['verify_code'] != Session::get('verify_code')) return ['code'=>'false','reason'=>'验证码错误'];
                    $real_admin = Db::table('gbox_admin')->where("id=1")->find();
                    $real_username = $real_admin['username'];
                    $real_password = $real_admin['password'];
                    if($submit['username'] == $real_username) {
                        if(md5($submit['password']) == $real_password) {
                            Db::table('gbox_admin')->where("id=1")->update([
                                'last_login_time' => date('Y-m-d H:i:s'),
                                'last_login_ip' => request()->ip()
                            ]);
                            Cookie::set('code2',base64_encode($real_username),86400);
                            Cookie::set('code',md5(date('Ymd').request()->ip().$real_username),86400);
                            return ['code'=>'success'];
                        } else {
                            return ['code'=>'false','reason'=>'账号或密码错误'];
                        }
                    } else {
                        return ['code'=>'false','reason'=>'账号不存在'];
                    }
                    
                case 'source_on':
                    if(Db::table('gbox_source')->where(['id'=>$submit['id']])->update(['state'=>0])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'启用失败'];
                case 'source_dis':
                    if(Db::table('gbox_source')->where(['id'=>$submit['id']])->update(['state'=>1])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'禁用失败'];
                case 'delete_more':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_source')->where(['id'=>$arr])->delete()) $i=$i+1;
                    }
                    return ['number'=>$i];
                case 'enable_more':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_source')->where(['id'=>$arr])->update(['state'=>0])) $i=$i+1;
                    }
                    return ['number'=>$i];
                case 'disable_more':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_source')->where(['id'=>$arr])->update(['state'=>1])) $i=$i+1;
                    }
                    return ['number'=>$i];
                
                case 'app_on':
                    if(Db::table('gbox_app')->where(['id'=>$submit['id']])->update(['state'=>0])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'显示失败'];
                case 'app_dis':
                    if(Db::table('gbox_app')->where(['id'=>$submit['id']])->update(['state'=>1])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'隐藏失败'];
                case 'delete_more_app':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_app')->where(['id'=>$arr])->delete()) $i=$i+1;
                    }
                    return ['number'=>$i];
                case 'enable_more_app':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_app')->where(['id'=>$arr])->update(['state'=>0])) $i=$i+1;
                    }
                    return ['number'=>$i];
                case 'disable_more_app':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_app')->where(['id'=>$arr])->update(['state'=>1])) $i=$i+1;
                    }
                    return ['number'=>$i];


                case 'puk_on':
                    if(Db::table('gbox_puk')->where(['id'=>$submit['id']])->update(['block'=>0])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'启用失败'];
                case 'puk_dis':
                    if(Db::table('gbox_puk')->where(['id'=>$submit['id']])->update(['block'=>1])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'禁用失败'];
                case 'delete_more_puk':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_puk')->where(['id'=>$arr])->delete()) $i=$i+1;
                    }
                    return ['number'=>$i];
                case 'enable_more_puk':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_puk')->where(['id'=>$arr])->update(['block'=>0])) $i=$i+1;
                    }
                    return ['number'=>$i];
                case 'disable_more_puk':
                    $id_arr = $submit['id'];
                    $i=0;
                    foreach ($id_arr as $arr) {
                        if(Db::table('gbox_puk')->where(['id'=>$arr])->update(['block'=>1])) $i=$i+1;
                    }
                    return ['number'=>$i];


                case 'add_source':
                    if($submit['allow_export'] == "allow") {
                        $export = "true";
                    } elseif ($submit['allow_export'] == 'refuse') {
                        $export = "false";
                    }
                    if(Db::table('gbox_source')->insert([
                        'id' => Db::table('gbox_source')->max('id')+1,
                        'name' => $submit['name'],
                        'introduce' => $submit['introduce'],
                        'linkTitle' => $submit['linkTitle'],
                        'linkUrl' => $submit['linkUrl'],
                        'author' => $submit['author'],
                        'export' => $export,
                        'icon' => $submit['head_image'],
                        'updateTime' => date('Y-m-d H:i:s'),
                        'sort' => $submit['sort'],
                        'state' => 0,
                        'password' => 'JM'.time()
                    ])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'添加失败'];
                case 'edit_source':
                    if($submit['allow_export'] == "allow") {
                        $export = "true";
                    } elseif ($submit['allow_export'] == 'refuse') {
                        $export = "false";
                    }
                    if(Db::table('gbox_source')->where(['id'=>$submit['id']])->update([
                        'name' => $submit['name'],
                        'introduce' => $submit['introduce'],
                        'linkTitle' => $submit['linkTitle'],
                        'linkUrl' => $submit['linkUrl'],
                        'author' => $submit['author'],
                        'export' => $export,
                        'icon' => $submit['head_image'],
                        'updateTime' => date('Y-m-d H:i:s'),
                        'sort' => $submit['sort']
                    ])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'修改失败'];
                    
                case 'getSort':
                    $id = $submit['id'];
                    $sort = Db::table('gbox_source')->where("id=$id")->value('sort');
                    $html='';
                    $i=0;
                    $sort = explode('|',$sort);
                    foreach ($sort as $arr) {
                        $html .= '<option value="'.$i.'">'.$arr.'</option>';
                        $i++;
                    }
                    return ['code'=>'success','number'=>$i,'content'=>$html];


                case 'addApp':
                    if($submit['lock'] == "allow") {
                        $lock = 1;
                    } elseif ($submit['lock'] == 'refuse') {
                        $lock = 0;
                    }
                    Db::table('gbox_source')->where(['id'=>$submit['belongTo']])->update(['updateTime'=>date('Y-m-d H:i:s')]);
                    if(Db::table('gbox_app')->insert([
                        'id' => Db::table('gbox_app')->max('id')+1,
                        'name' => $submit['name'],
                        'introduce' => $submit['introduce'],
                        'image' => $submit['head_image'],
                        'lock' => $lock,
                        'version' => $submit['version'],
                        'appType' => $submit['type'],
                        'cateindex' => $submit['sort'],
                        'content' => $submit['content'],
                        'belongTo' => $submit['belongTo'],
                        'updateTime' => date('Y-m-d H:i:s')
                    ])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'error'];
                case 'editApp':
                    if($submit['lock'] == "allow") {
                        $lock = 1;
                    } elseif ($submit['lock'] == 'refuse') {
                        $lock = 0;
                    }
                    $source_id = Db::table('gbox_app')->where(['id'=>$submit['id']])->value('belongTo');
                    Db::table('gbox_source')->where(['id'=>$source_id])->update(['updateTime'=>date('Y-m-d H:i:s')]);
                    if(Db::table('gbox_app')->where(['id'=>$submit['id']])->update([
                        'name' => $submit['name'],
                        'introduce' => $submit['introduce'],
                        'image' => $submit['head_image'],
                        'lock' => $lock,
                        'version' => $submit['version'],
                        'appType' => $submit['type'],
                        'cateindex' => $submit['sort'],
                        'content' => $submit['content'],
                        'belongTo' => $submit['belongTo'],
                        'updateTime' => date('Y-m-d H:i:s')
                    ])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'error'];
                
                case 'addPuk':
                    $number = $submit['number'];
                    $length = 16;
                    $prefix = 'G';
                    $n=0;
                    $expireTime = $submit['time'];
                    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $codes = [];
                    for ($i = 0; $i < $number; $i++) {
                        $randomCode = $prefix;
                        for ($j = 1; $j < $length; $j++) { // 从1开始因为第一个字符是前缀G
                            $randomCode .= $characters[rand(0, $charactersLength - 1)];
                        }
                        $codes[] = $randomCode;
                    }
                    $maxID = Db::table('gbox_puk')->max('id')+1;
                    foreach ($codes as $code) {
                        Db::table('gbox_puk')->insert([
                            'id' => $maxID,
                            'pukContent' => $code,
                            'addTime' => date('Y-m-d H:i:s'),
                            'expireTime' => $expireTime,
                            'belongTo' => $submit['source']
                        ]);
                        $n++;
                        $maxID++;
                    }
                    return ['code'=>'success','number'=>$n];
                    
                case 'block_udid':
                    if(!empty(Db::table('gbox_block')->where(['udid'=>$submit['id']])->find())) return ['code'=>'false','reason'=>'此UDID已在黑名单中'];
                    if(Db::table('gbox_block')->insert([
                        'id' => Db::table('gbox_block')->max("id")+1,
                        'udid' => $submit['id']
                    ])) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'error'];
                case 'out_block':
                    if(Db::table('gbox_block')->where(['udid'=>$submit['id']])->delete()) return ['code'=>'success'];
                    return ['code'=>'false','reason'=>'error'];
                    
                case 'editPwd':
                    $yuan = $submit['yuan'];
                    if(Db::table('gbox_admin')->where('id=1')->value('password') != md5($yuan)) return ['code'=>"false",'reason'=>'原密码错误'];
                    if(Db::table('gbox_admin')->where('id=1')->update([
                        'username' => $submit['username'],
                        'password' => md5($submit['newp'])
                    ])) {
                        Cookie::delete('code');
                        Cookie::delete('code2');
                        return ['code'=>'success'];
                    }
                    
                case 'pukExport':
                    $content='';$i=0;
                    foreach ($submit['pukContent'] as $arr) {
                        $content .= $arr.'
';
                        $i++;
                    }
                    $filename = '导出_'.date('Y_m_d_His').'_'.mt_rand(1,9999).'_'.$i.'张.txt';
                    file_put_contents('./exportPuk/'.$filename,$content);
                    $url = request()->domain().'/exportPuk/'.$filename;
                    return ['code'=>'success','url'=>$url,'name'=>$filename];
            }
        }
        
        public function forceUpdate()
        {
            $this->login_state();
            return view();
        }
        
        public function source_data_api()
        {
            $this->login_state();
            $get = request()->get();
            $page = $get['page'];
            $limit = $get['limit'];
            // 基础查询条件
            $query = Db::table('gbox_source')->order('id asc');
            $query2 = Db::table('gbox_source')->order('id asc');

            // 状态筛选
            if(!empty($get['state'])) {
                $state = $get['state'];
                switch($state) {
                    case '1':
                        $query->where(['state' => 0]);
                        $query2->where(['state' => 0]);
                        break;
                    case '2':
                        $query->where(['state' => 1]);
                        $query2->where(['state' => 1]);
                        break;
                }
            }
            // 作者筛选
            if (!empty($get['author'])) {
                $author = $get['author'];
                $query->where(['author'=>$author]);
                $query2->where(['author'=>$author]);
            }
            // ID筛选
            if (!empty($get['id'])) {
                $id = $get['id'];
                $query->where(['id'=>$id]);
                $query2->where(['id'=>$id]);
            }
            // 名称筛选
            if (!empty($get['name'])) {
                $name = $get['name'];
                $query->where(['name'=>$name]);
                $query2->where(['name'=>$name]);
            }
            
            // 获取最终结果
            $array = $query->page($page)->limit($limit)->select();
            $count = $query2->count();

            for($i = 0; $i<$limit;$i++) {
                if(empty($array[$i])) break;
                if($array[$i]['state'] == 0) {
                    $array[$i]['state'] = '<span style="color: green">正常</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-danger' onclick='dis(`".$array[$i]['id']."`)'>禁用</button>";
                } elseif ($array[$i]['state'] == 1) {
                    $array[$i]['state'] = '<span style="color: red">已禁用</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-normal' onclick='on(`".$array[$i]['id']."`)'>启用</button>";
                }
                $array[$i]['link'] = request()->domain().'/Source/'.$array[$i]['id'];
                $array[$i]['mod'] .= "<button class='layui-btn layui-btn-xs layui-btn-primary' onclick='edit(`".$array[$i]['id']."`)'>编辑</button><button class='layui-btn layui-btn-xs layui-bg-purple' onclick='copyToClip(`".$array[$i]['link']."`)'>复制源地址</button></div>";
                $array[$i]['icon'] = '<img src="/upload/'.$array[$i]['icon'].'" style="width:20px">';
            }
            $json = json_decode(json_encode($array), true); //将$array转化为关联数组，并保存在$json中
            $json_back = array("code" => 0, "msg" => "", "count" => $count, "data" => $json); 
            echo json_encode($json_back);
        }
        
        public function app_data_api()
        {
            $this->login_state();
            $get = request()->get();
            $page = $get['page'];
            $limit = $get['limit'];
            // 基础查询条件
            $query = Db::table('gbox_app')->order('id asc');
            $query2 = Db::table('gbox_app')->order('id asc');

            // 所属源筛选
            if(!empty($get['source'])) {
                $source_id = $get['source'];
                $query->where(['belongTo'=>$source_id]);
                $query2->where(['belongTo'=>$source_id]);
            }
            // 上锁筛选
            if (!empty($get['lock'])) {
                $lock = $get['lock'];
                if($lock=="no")$lock=0;
                $query->where(['lock'=>$lock]);
                $query2->where(['lock'=>$lock]);
            }
            // ID筛选
            if (!empty($get['id'])) {
                $id = $get['id'];
                $query->where(['id'=>$id]);
                $query2->where(['id'=>$id]);
            }
            // 名称筛选
            if (!empty($get['name'])) {
                $name = $get['name'];
                $query->where(['name'=>$name]);
                $query2->where(['name'=>$name]);
            }
            
            // 获取最终结果
            $array = $query->page($page)->limit($limit)->select();
            $count = $query2->count();

            for($i = 0; $i<$limit;$i++) {
                if(empty($array[$i])) break;
                if($array[$i]['appType'] == "LINK") {
                    $array[$i]['appType'] = '超链接';
                } elseif ($array[$i]['appType'] == "SELF_SIGN") {
                    $array[$i]['appType'] = '自签型';
                } elseif ($array[$i]['appType'] == "ENT_SIGN") {
                    $array[$i]['appType'] = '企业签';
                }
                if($array[$i]['lock'] == 0) {
                    $array[$i]['lock'] = '未上锁';
                } elseif ($array[$i]['lock'] == 1) {
                    $array[$i]['lock'] = '已上锁';
                }
                if($array[$i]['state'] == 0) {
                    $array[$i]['state'] = '<span style="color: green">正常</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-danger' onclick='dis(`".$array[$i]['id']."`)'>隐藏</button>";
                } elseif ($array[$i]['state'] == 1) {
                    $array[$i]['state'] = '<span style="color: red">已隐藏</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-normal' onclick='on(`".$array[$i]['id']."`)'>显示</button>";
                }
                $array[$i]['mod'] .= "<button class='layui-btn layui-btn-xs layui-btn-primary' onclick='edit(`".$array[$i]['id']."`)'>编辑</button></div>";
                $array[$i]['image'] = '<img src="/upload/'.$array[$i]['image'].'" style="width:20px">';
            }
            $json = json_decode(json_encode($array), true); //将$array转化为关联数组，并保存在$json中
            $json_back = array("code" => 0, "msg" => "", "count" => $count, "data" => $json); 
            echo json_encode($json_back);
        }
        
        public function puk_data_api()
        {
            $this->login_state();
            $get = request()->get();
            $page = $get['page'];
            $limit = $get['limit'];
            // 基础查询条件
            $query = Db::table('gbox_puk')->order('id asc');
            $query2 = Db::table('gbox_puk')->order('id asc');

            // 所属源筛选
            if(!empty($get['source'])) {
                $source_id = $get['source'];
                $query->where(['belongTo'=>$source_id]);
                $query2->where(['belongTo'=>$source_id]);
            }
            // 状态筛选
            if (!empty($get['state'])) {
                $state = $get['state'];
                if($state=='1')$state=0;if($state=='2')$state=1;if($state=='3')$state=2;
                $query->where(['state'=>$state]);
                $query2->where(['state'=>$state]);
            }
            // UDID筛选
            if (!empty($get['udid'])) {
                $udid = $get['udid'];
                $query->where(['udid'=>$udid]);
                $query2->where(['udid'=>$udid]);
            }
            // ID筛选
            if (!empty($get['id'])) {
                $id = $get['id'];
                $query->where(['id'=>$id]);
                $query2->where(['id'=>$id]);
            }
            // 内容筛选
            if (!empty($get['pukContent'])) {
                $pukContent = $get['pukContent'];
                $query->where(['pukContent'=>$pukContent]);
                $query2->where(['pukContent'=>$pukContent]);
            }
            
            // 获取最终结果
            $array = $query->page($page)->limit($limit)->select();
            $count = $query2->count();

            for($i = 0; $i<$limit;$i++) {
                if(empty($array[$i])) break;
                $array[$i]['belongTo'] = Db::table('gbox_source')->where(['id'=>$array[$i]['belongTo']])->value('name');
                if($array[$i]['state'] == 0) {
                    $array[$i]['state'] = '<span style="color: green">未使用</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-normal' onclick='dis(`".$array[$i]['id']."`)'>禁用</button>";
                } elseif ($array[$i]['state'] == 1) {
                    $array[$i]['state'] = '<span style="color: red">已使用</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-normal' onclick='dis(`".$array[$i]['id']."`)'>禁用</button>";
                    $array[$i]['mod'] .= "<button class='layui-btn layui-btn-xs layui-btn-danger' onclick='block(`".$array[$i]['udid']."`)'>拉黑UDID</button></div>";
                }
                if($array[$i]['block'] == 1) {
                    $array[$i]['block'] = '<span style="color: red">已禁用</span>';
                    $array[$i]['mod'] = "<div class='layui-btn-group'><button class='layui-btn layui-btn-xs layui-btn-normal' onclick='ena(`".$array[$i]['id']."`)'>解禁</button>";
                } else {
                    $array[$i]['block'] = '<span style="color: green">正常</span>';
                }
                $array[$i]['expireTime'] = date('Y-m-d H:i:s',$array[$i]['expireTime']);
            }
            $json = json_decode(json_encode($array), true); //将$array转化为关联数组，并保存在$json中
            $json_back = array("code" => 0, "msg" => "", "count" => $count, "data" => $json); 
            echo json_encode($json_back);
        }
        
        public function block_data_api()
        {
            $this->login_state();
            $get = request()->get();
            $page = $get['page'];
            $limit = $get['limit'];
            // 基础查询条件
            $query = Db::table('gbox_block')->order('id asc');
            $query2 = Db::table('gbox_block')->order('id asc');

            // ID筛选
            if(!empty($get['id'])) {
                $id = $get['id'];
                $query->where(['id'=>$id]);
                $query2->where(['id'=>$id]);
            }
            // UDID筛选
            if (!empty($get['udid'])) {
                $udid = $get['udid'];
                $query->where(['udid'=>$udid]);
                $query2->where(['udid'=>$udid]);
            }
            
            // 获取最终结果
            $array = $query->page($page)->limit($limit)->select();
            $count = $query2->count();

            for($i = 0; $i<$limit;$i++) {
                if(empty($array[$i])) break;
                $array[$i]['mod'] = "<button class='layui-btn layui-btn-xs layui-btn-normal' onclick='out_block(`".$array[$i]['udid']."`)'>解除拉黑</button>";
            }
            $json = json_decode(json_encode($array), true); //将$array转化为关联数组，并保存在$json中
            $json_back = array("code" => 0, "msg" => "", "count" => $count, "data" => $json); 
            echo json_encode($json_back);
        }
        
        public function ranking_data_api()
        {
            $this->login_state();
            $get = request()->get();
            $page = $get['page'];
            $limit = $get['limit'];
            
            $allSource = Db::table('gbox_source')->select();
            if(empty($allSource)) {
                $json_back = array("code" => 0, "msg" => "", "count" => 0, "data" => ""); 
                exit(json_encode($json_back));
            }
            $i = 1;
            foreach ($allSource as $sourceForeach) {
                $id = $sourceForeach['id'];
                $ranking[$i]['id'] = $id;
                $ranking[$i]['name'] = $sourceForeach['name'];
                $ranking[$i]['user_number'] = Db::table('gbox_puk')->where(['belongTo'=>$id])->where("state>=1")->count();
                $i++;
            }
            
            usort($ranking, function($a, $b) {
                return $b['user_number'] - $a['user_number'];
            });
            
            $json = json_decode(json_encode($ranking), true); //将$array转化为关联数组，并保存在$json中
            $json_back = array("code" => 0, "msg" => "", "count" => Db::table('gbox_source')->count(), "data" => $json); 
            echo json_encode($json_back);
        }
        
        /*
        * 获取服务器系统
        */
        private function getSystem()
        {
            if(strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                return 'Windows';
            } elseif (strtoupper(substr(PHP_OS, 0, 3)) === 'LIN') {
                return 'Linux';
            }
        }
        
        
        /*
        * 获取服务器核心数
        */
        private function getCpuCores()
        {
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                // Windows 下获取核心数量
                $output = shell_exec('WMIC CPU Get NumberOfCores');
                // 解析输出，获取核心数量
                preg_match('/\d+/', $output, $matches);
                return $matches[0];
            } else {
                // Linux 下获取核心数量
                $output = shell_exec('nproc');
                return $output;
            }
        }


        /*
        * 获取服务器内存大小
        */
        private function getServerMemorySize()
        {
            // 在这里根据实际情况获取服务器内存大小
            // 这里使用的是 Linux 下的 free 命令，Windows 下可能需要不同的命令
            if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
                // Linux 下获取内存信息
                $output = shell_exec('free -m');
                // 解析输出，获取内存大小
                preg_match('/Mem:\s+(\d+)/', $output, $matches);
                return $matches[1] . ' MB';
            } else {
                // Windows 下获取内存信息（请根据实际情况调整命令）
                return 'N/A';
            }
        }
        /*
        * 登录状态判断
        */
        private function login_state()
        {
            $code = Cookie::get('code');
            $date = date('Ymd');
            $ip = request()->ip();
            $user = base64_decode(Cookie::get('code2'));
            if($code != md5($date.$ip.$user)) {
                exit("<script>window.location.href='".url('login')."'</script>");
            }
        }
        
        public function verify_code()
        {
            $num = 4;
            $w = 60;
            $h = 20;
            $code = "";
            for ($i = 0; $i < $num; $i++) {
                $code .= rand(0, 9);
            }
            //4位验证码也可以用rand(1000,9999)直接生成
            //将生成的验证码写入session，备验证时用
            Session::set('verify_code', $code);
            //创建图片，定义颜色值
            header("Content-type: image/PNG");
            $im = imagecreate($w, $h);
            $black = imagecolorallocate($im,110,255,51);
            $gray = imagecolorallocate($im, 255,87,51);
            $bgcolor = imagecolorallocate($im, 255, 255, 255);
            //填充背景
            imagefill($im, 0, 0, $gray);
            //随机绘制两条虚线，起干扰作用
            $style = array($black, $black, $black, $black, $black, $gray, $gray, $gray, $gray, $gray);
            imagesetstyle($im, $style);
            $y1 = rand(0, $h);
            $y2 = rand(0, $h);
            $y3 = rand(0, $h);
            $y4 = rand(0, $h);
            imageline($im, 0, $y1, $w, $y3, IMG_COLOR_STYLED);
            imageline($im, 0, $y2, $w, $y4, IMG_COLOR_STYLED);
            //在画布上随机生成大量黑点，起干扰作用;
            for ($i = 0; $i < 80; $i++) {
                imagesetpixel($im, rand(0, $w), rand(0, $h), $black);
            }
            //将数字随机显示在画布上,字符的水平间距和位置都按一定波动范围随机生成
            $strx = rand(3, 8);
            for ($i = 0; $i < $num; $i++) {
                $strpos = rand(1, 6);
                imagestring($im, 5, $strx, $strpos, substr($code, $i, 1), $black);
                $strx += rand(8, 12);
            }
            //画边框
            imagerectangle($im, 0, 0, $w - 1, $h - 1, imagecolorallocate($im,0,0,0));
            imagepng($im);//输出图片
            imagedestroy($im);//释放图片所占内存
        }
        public function out()
        {
            Cookie::delete('code');
            Cookie::delete('code2');
            echo "<script>window.location.href='".url('login')."'</script>";
        }
    }
