<?php
return [
'type'            => 'mysql',
'hostname'        => 'localhost',
'database'        => 'gbox',
'username'        => 'gbox',
'password'        => 'jiamu0217',
'charset'         => 'utf8',
'prefix'          => '',
'debug'           => true,
];