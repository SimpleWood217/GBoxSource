<?php

    namespace app\index\controller;

    use think\Controller;
    use think\view;
    use think\Db;
    use think\Route;
    use think\request;
    use think\Cookie;
    use think\Session;

    class Index extends Controller
    {
        public function index()
        {
            return view();
        }
        
        public function auth($id)
        {
            error_reporting(E_ERROR); 
            ini_set("display_errors","Off");
            include_once EXTEND_PATH . 'RNCryptor.class.php';
                        
            $data = file_get_contents("php://input");
            $password = md5(request()->domain().'/Source/'.$id);
            $cryptor = new \Decryptor();
            $strParams = $cryptor->decrypt($data, $password);
            
            $params = json_decode($strParams, true);
            $udid = $params['udid'];
            $pwd = $params['pwd'];
            // $udid = $_GET['udid'];                //用户所提交的udid
            // $pwd = $_GET['pwd'];                  //用户所提交的密码
            $timestamp = $params['timestamp'];
            
            $errorMsg = '兑换失败';
            $puk = Db::table('gbox_puk')->where(['pukContent'=>$pwd])->find();
            //判断该udid是否在黑名单中
            if (!empty(Db::table('gbox_block')->where(['udid'=>$udid])->find())) {
                $errorMsg = '你在黑名单列表，无法解锁';
                exit($this->fail($errorMsg));
            }
            if(empty($puk)) {
                $errorMsg = '解锁码不存在';
                exit($this->fail($errorMsg));
            }
            if($puk['block'] == 1) {
                $errorMsg = '此解锁码已被封禁，无法解锁';
                exit($this->fail($errorMsg));
            }
            if ($puk['belongTo'] == $id) {} else {
                $errorMsg = '此解锁码不属于该源，无法解锁';
                exit($this->fail($errorMsg));
            }
            if(time() >= strtotime($puk['useTime'] . ' +' . $puk['expireTime'] . ' days')) {
                $errorMsg = '此解锁码已过期，无法解锁';
                exit($this->fail($errorMsg));
            }
            if($puk['state'] == 1) {
                if($puk['udid'] == $udid) {
                    echo $this->ok($id);
                }
            } elseif($puk['state'] == 0) {
                Db::table('gbox_puk')->where(['pukContent'=>$pwd])->update([
                    'state' => 1,
                    'udid' => $udid,
                    'userIP' => request()->ip(),
                    'useTime' => date('Y-m-d H:i:s'),
                    'useDate' => date('Y-m-d')
                ]);
                echo $this->ok($id);
            }
        }
        public function ok($id)
        {
            $apps = Db::table('gbox_app')->where(['belongTo'=>$id])->select();
            $data = '{"success":true,"data":[';
            $comma = '';
            foreach ($apps as $arr) {
                $data .= $comma . '"' . $arr['content'] . '"';
                $comma = ','; // 设置下一次循环添加逗号
            }
            $data .= ']}';
            return $data;
        }
        
        public function fail($errorMsg)
        {
            $json = array(
                'success' => false,
                'message' => $errorMsg
            );
            return json_encode($json);
        }
    }
