<?php

    namespace app\index\controller;

    use think\Controller;
    use think\view;
    use think\Db;
    use think\Route;
    use think\request;
    use think\Cookie;
    use think\Session;
    

    class BuildSource extends Controller
    {
        public function index($id)
        {
            if(empty(Db::table('gbox_source')->where("id=$id")->find())) echo "不存在该源";
            $sourceCode = $this->build($id);
            echo $sourceCode;
        }
        private function build($id)
        {
            $sourceInfo = Db::table('gbox_source')->where("id=$id")->find();
            
            if($sourceInfo['state'] == 1) return $this->emptySource();
            
            $version = config('build')['version'];
            $author = $sourceInfo['author'];
            $name = $sourceInfo['name'];
            $introduce = $sourceInfo['introduce'];
            $linkUrl = $sourceInfo['linkUrl'];
            $linkTitle = $sourceInfo['linkTitle'];
            $author = $sourceInfo['author'];
            $author = $sourceInfo['author'];
            $export = $sourceInfo['export'];
            $icon = $sourceInfo['icon'];
            $upateTime = $sourceInfo['updateTime'];
            
            $sort = $sourceInfo['sort'];
            $html = '';
            $sort = explode('|', $sort);
            $comma = '';
            foreach ($sort as $arr) {
                $html .= $comma . '"' . $arr . '"';
                $comma = ',';
            }
            $domain = request()->domain();
            // $password = config('build')['password'];
            $password = $sourceInfo['password'];
            $password = $this->rsa($password);
            $upateTime = $this->dateUpdate($upateTime);
            $appRepositories = $this->appRepositories($sourceInfo['id'],$sourceInfo['password']);
            
            $json = '{
                        "version": "'.$version.'",
                        "sourceName": "'.$name.'",
                        "sourceAuthor": "'.$author.'",
                        "sourceEncryptionKey": "'.$password.'",
                        "sourceExportEnable": '.$export.',
                        "sourceLinkTitle": "'.$linkTitle.'",
                        "sourceLinkUrl": "'.$linkUrl.'",
                        "sourceImage": "'.$domain.'/upload/'.$icon.'",
                        "sourceUpdateTime": "'.$upateTime.'",
                        "sourceProcessor": {
                            "appsUnlock": {
                                "authUrl": "'.$domain.'/Auth/'.$sourceInfo['id'].'",
                                "actions": [
                                    {
                                        "title": "'.$linkTitle.'",
                                        "openUrl": "'.$linkUrl.'"
                                    }
                                ],
                                "description": "软件需要购买解锁码使用,任意解锁一个软件即全部解锁"
                            }
                        },
                        "sourceDescription": "'.$introduce.'",
                        "appCategories": ['.$html.'],
                        "appRepositories": "'.$appRepositories.'"
                    }';
            echo $json;
        }
        private function dateUpdate($date)
        {
            //时区
            $timezone = new \DateTimeZone('Asia/Shanghai');
            // 创建 DateTime 对象并设置时区
            $date = \DateTime::createFromFormat('Y-m-d H:i:s', $date, $timezone);
            
            if ($date === false) {
                echo "错误: 无法解析日期时间字符串。\n";
            } else {
                // 将日期时间对象格式化为 ISO 8601 格式
                $iso8601String = $date->format('Y-m-d\TH:i:sP');
                return $iso8601String;
            }
        }
        private function appRepositories($sourceId,$password)
        {
            $allApp = Db::table('gbox_app')->where("belongTo=$sourceId")->select();
            $data = [];
            foreach ($allApp as $arr) {
                $lock = ($arr['lock'] == 0) ? false : true; // 锁定状态的转换
                $upateTime = $this->dateUpdate($arr['updateTime']);
                $domain = request()->domain().'/upload/';
                if($arr['appType'] == 'LINK') {
                    $type = 'appLink';
                    $typeContent = $arr['content'];
                } else {
                    if($lock == false) {
                        $type = 'appPackage';
                        $typeContent = $arr['content'];
                    } else {
                        $type = 'appPackage';
                        $typeContent = md5($arr['content']);
                    }
                }
                $data[] = [
                    "lock" => $lock,
                    "appType" => $arr['appType'],
                    "appCateIndex" => $arr['cateindex'],
                    "appUpdateTime" => $upateTime,
                    "appName" => $arr['name'],
                    "appVersion" => $arr['version'],
                    "appImage" => $domain . $arr['image'],
                    $type => $typeContent,
                    "appDescription" => $arr['introduce']
                ];
            }
            
            $data = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            
            include_once EXTEND_PATH . 'RNCryptor.php';
            $encryptor = new \Encryptor();
            $data = $encryptor->encrypt($data, $password);
            return $data;
        }
        private function emptySource()
        {
            $json = '{
                        "version": "1.0",
                        "sourceName": "此软件源已被停用",
                        "sourceAut
                        hor": "此软件源已被停用",
                        "sourceEncryptionKey": "1",
                        "sourceExportEnable": false,
                        "sourceLinkTitle": "",
                        "sourceLinkUrl": "",
                        "sourceImage": "",
                        "sourceUpdateTime": "",
                        "sourceDescription": "此软件源已被停用",
                        "appCategories": [
                        ],
                        "appRepositories": ""
                    }';
            return $json;
        }
        private function rsa($pwd)
        {
            include_once EXTEND_PATH . 'RSA.php';
            $config = array(
                'public_key'  => "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCTf0w+7Ro9POX1O029zw/Ne5um\nIWYntFDlyoSXjDfwuK5lRKZvs5WnUfiJnpuKV24schKdkULsS/wPQvx0xPdtfAvG\n0+gKhumUoNgc4ObflRs93QyTEfTS1Z83+LTGyLLMlKNh+qmZsg969v3RLydTXcJI\npIvR3cxQ42JLX7ZZGwIDAQAB\n-----END PUBLIC KEY-----"
            );
            $rsa = new \RSA($config);
            $en = $rsa->encryptByPublicKey($pwd);
            return $en;
        }
    }