            var is_scroll = false, is_checked = false, out_time = null;
            var ubind_click = document.getElementsByClassName('ubind_click')[0],
                    _select_btn = document.getElementsByClassName('btn_submit')[0];
            ubind_click.addEventListener('click', function () {
                if (!is_scroll) {
                    set_licenes({msg: '请下拉滚动条并阅读《用户协议》'})
                    return false;
                }
                var select_ground = this.getElementsByClassName('select_ground')[0],
                        btn_submit = document.getElementsByClassName('btn_submit')[0];
                if (hasClass(select_ground, 'pitch')) {
                    removeClass(select_ground, 'pitch');
                    addClass(btn_submit, 'disabled');
                    is_checked = false;
                } else {
                    addClass(select_ground, 'pitch');
                    removeClass(btn_submit, 'disabled');
                    is_checked = true;
                }
            }, false);
            document.getElementsByClassName('conter_tips')[0].onscroll = function (e) {
                var conter_shadow = document.getElementsByClassName('conter_shadow'),
                        conter_read_tips = document.getElementsByClassName('conter_read_tips')[0],
                        conter_text = conter_read_tips.getElementsByTagName('span')[0]
                var scrollHeight = this.scrollHeight - this.clientHeight - 10;
                console.log(this.scrollTop, scrollHeight)
                if (this.scrollTop === 0) {
                    replaceClass(conter_shadow[0], 'show', 'hide');
                    replaceClass(conter_shadow[1], 'hide', 'show');
                } else if (this.scrollTop > 0 && this.scrollTop < scrollHeight) {
                    replaceClass(conter_shadow[0], 'hide', 'show');
                    replaceClass(conter_shadow[1], 'hide', 'show');
                } else if (this.scrollTop > scrollHeight) {
                    replaceClass(conter_shadow[0], 'hide', 'show');
                    replaceClass(conter_shadow[1], 'show', 'hide');
                    is_scroll = true;
                }
                if (!is_scroll) {
                    conter_text.innerText = Math.round(this.scrollTop / scrollHeight * 100) + '%';
                } else {
                    addClass(conter_read_tips, 'active');
                    conter_read_tips.innerText = '已完成阅读'
                }
            }
            // 主视图自适应
            function auto_mian() {
                var win_height = window.innerHeight,
                        main = document.getElementsByClassName('main')[0];
                conter_tips = main.getElementsByClassName('conter_tips')[0];
                main.style.cssText = 'display:block;height:' + (win_height - 50) + 'px;'
                conter_tips.style.height = (win_height - 380) + 'px'
            }
            //判断class是否存在
            function hasClass(elem, cls) {
                cls = cls || '';
                if (cls.replace(/\s/g, '').length == 0)
                    return false;
                return new RegExp(' ' + cls + ' ').test(' ' + elem.className + ' ');
            }

            //添加class
            function addClass(elem, cls) {
                if (!hasClass(elem, cls)) {
                    elem.className = elem.className == '' ? cls : elem.className + ' ' + cls;
                }
            }

            //删除class
            function removeClass(elem, cls) {
                if (hasClass(elem, cls)) {
                    var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, '') + ' ';
                    while (newClass.indexOf(' ' + cls + ' ') >= 0) {
                        newClass = newClass.replace(' ' + cls + ' ', ' ');
                    }
                    elem.className = newClass.replace(/^\s+|\s+$/g, '');
                }
            }

            //替换class
            function replaceClass(elem, cls, newCls) {
                removeClass(elem, cls);
                addClass(elem, newCls);
            }

            // 打开面板
            function open_panel() {
                if (!is_scroll) {
                    set_licenes({msg: '请下拉滚动条并阅读《用户协议》'});
                    return false;
                }
                if (!is_checked) {
                    set_licenes({msg: '请勾选已阅读并同意《用户协议》选项'});
                    return false;
                }
                window.location.href = "./?step=2";
            }
            // 设置消息提示
            function set_licenes(config) {
                var select_tips = document.getElementsByClassName('select_tips')[0];
                select_tips.innerText = config.msg;
                select_tips.style.display = 'block';
                clearTimeout(out_time);
                out_time = setTimeout(function () {
                    select_tips.style.display = 'none';
                }, config.time || 3000);
            }

            window.onresize = function () {
                auto_mian();
            }
            window.onload = function () {
                auto_mian();
            }