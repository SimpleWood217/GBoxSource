<?php 
    $lock_file = './install.lock';
    if (file_exists($lock_file)) {
        exit("安装锁已存在，如需重新安装请删除install.lock");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GBoxSource | 安装程序</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
</head>
<body>
    <div class="container">
        <?php if (!isset($_GET['step']) || $_GET['step'] == 1): ?>
        <style>
            iframe{
                width: 100%;
                height:100vh;
                border:none;
            }
        </style>
        <link rel="stylesheet" href="./user_agreement.css">
        <?php echo file_get_contents('https://www.jm217.cn/gbox.php/user_agreement'); ?>
        <script src="./user_agreement.js"></script>
        <?php elseif ($_GET['step'] == 2): ?>
        <link rel="stylesheet" href="./body.css">
        <center><h1>GBoxSource - 安装程序</h1></center>
        <hr />
        <h3>步骤二：环境检测</h3>
        
<?php

// PHP 版本检测
$php_version = PHP_VERSION;
$php_supported_versions = ['7.0', '7.1', '7.2'];
$php_version_supported = in_array(substr($php_version, 0, 3), $php_supported_versions);

// 读写权限检测
$read_write_supported = is_readable('.') && is_writable('.');

// shell_exec 是否被禁用检测
$shell_exec_enabled = function_exists('shell_exec');

// 构建检测结果数组
$check_results = [
    ['检测项', '检测结果'],
    ['PHP 版本(支持7.0-7.2)', $php_version_supported ? '支持' : '不支持'],
    ['读写权限', $read_write_supported ? '支持' : '不支持'],
    ['shell_exec函数是否被禁用', $shell_exec_enabled ? '支持' : '已禁用'],
];

// 检查是否有不符合的情况
foreach ($check_results as $index => $row) {
    if ($index > 0 && $row[1] !== '支持') {
        $check_flag = 1; // 发现不符合项，标志为1
        break;
    }
}

// 输出检测结果表格
echo '<table class="layui-table">';
foreach ($check_results as $row) {
    echo '<tr>';
    foreach ($row as $cell) {
        echo '<td>' . htmlspecialchars($cell) . '</td>';
    }
    echo '</tr>';
}
echo '</table>';

if($check_flag === 1) {
    echo '<button class="layui-btn" onclick="location.reload()">重新检测</button>';
} else {
    echo '<button class="layui-btn" onclick="window.location.href=`./?step=3`">下一步</button>';
}
?>

        
        <?php elseif ($_GET['step'] == 3): ?>
        <link rel="stylesheet" href="./body.css">
        
        
        <center><h1>GBoxSource - 安装程序</h1></center>
        <hr />
        <h3>步骤三：配置信息</h3>
        <br>
<form action="" method="post" class="layui-form">
        <?php
        if(isset($_POST['submit'])) {
            if(empty($_POST['host']) || empty($_POST['user']) || empty($_POST['psw']) || empty($_POST['db'])) {
                exit("<div style='color:red'>请填写完整的数据库连接信息和通讯密钥<a style='color: blue' href='javascript:window.location.href=`./?step=3`;'> 重新填写</a></div>");
            } else {
                $host = $_POST['host'];
                $user = $_POST['user'];
                $psw = $_POST['psw'];
                $db = $_POST['db'];
        
                // 写入配置文件
                $config_file = "../../application/database.php";
                $config_strings = "<?php\n";
                $config_strings .= "return [\n";
                $config_strings .= "'type'            => 'mysql',\n";
                $config_strings .= "'hostname'        => '$host',\n";
                $config_strings .= "'database'        => '$db',\n";
                $config_strings .= "'username'        => '$user',\n";
                $config_strings .= "'password'        => '$psw',\n";
                $config_strings .= "'charset'         => 'utf8',\n";
                $config_strings .= "'prefix'          => '',\n";
                $config_strings .= "'debug'           => true,\n";
                $config_strings .= "];";
        
                $fp = fopen($config_file, "wb");
                if($fp === false) {
                    exit("<div style='color:red'>无法写入配置文件，请检查目录权限。<a style='color: blue' href='javascript:window.location.href=`./?step=3`;'> 返回</a></div>");
                } else {
        
                    // 导入 SQL 文件到数据库
                    $sql_file = "./GBox.sql";
                    $conn = mysqli_connect($host, $user, $psw, $db);
                    if(!$conn) {
                        exit("<div style='color:red'>无法连接数据库，请检查数据库连接信息。<a style='color: blue' href='javascript:window.location.href=`./?step=3`;'> 重新填写</a></div>");
                    } else {
                        fwrite($fp, $config_strings);
                        fclose($fp);
                        echo "<div style='color:green'>配置文件写入成功！</div>";
                        $sql_content = file_get_contents($sql_file);
                        $queries = explode(';', $sql_content);
                        foreach($queries as $query) {
                            if(trim($query) != '') {
                                $result = mysqli_query($conn, $query);
                                if(!$result) {
                                    echo "<div style='color:red'>导入 SQL 文件出错，请检查 SQL 文件内容。</div>";
                                    break;
                                }
                            }
                        }
                        echo "<div style='color:green'>SQL 文件导入成功！</div>";
                        // 创建 install.lock 文件
                        $lock_file =  './install.lock';
                        if(!file_exists($lock_file)) {
                            $lock_fp = fopen($lock_file, 'w');
                            fclose($lock_fp);
                            echo "<div style='color:green'>install.lock 安装锁创建成功！</div>";
                        } else {
                            echo "<div style='color:red'>install.lock 安装锁已存在！</div>";
                        }
                        echo "<div>后台登录地址：http://域名/admin</div><div> 登录账号：admin</div><div> 登录密码：123456</div>";
                        exit('安装成功 <a style="color:blue" href="/admin">点我跳转</a>');
                    }
                }
            }
        }
        ?>


            <div class="layui-form-item">
                <input type="text" name="host" placeholder="数据库地址" autocomplete="off" class="layui-input">
                *一般为localhost
            </div>
            <div class="layui-form-item">
                <input type="text" name="user" placeholder="数据库用户名" autocomplete="off" class="layui-input">
                *请输入您的数据库用户名
            </div>
            <div class="layui-form-item">
                <input type="password" name="psw" placeholder="数据库密码" autocomplete="off" class="layui-input">
                *请输入您的数据库密码
            </div>
            <div class="layui-form-item">
                <input type="text" name="db" placeholder="数据库名" autocomplete="off" class="layui-input">
                *请输入您的数据库名
            </div>
            <div class="layui-form-item">
                <button type="submit" class="layui-btn" name="submit">提交</button>
            </div>
        </form>
        
        
        
        <?php endif; ?>
    </div>
    <script src="../static/jqu.js"></script>
    <script src="/static/layui/layui.js"></script>
</body>
</html>
