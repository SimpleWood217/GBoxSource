-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: gbox
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `gbox_admin`
--

DROP TABLE IF EXISTS `gbox_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gbox_admin` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `username` text NOT NULL COMMENT '账号',
  `password` text NOT NULL COMMENT '密码',
  `last_login_time` datetime NOT NULL COMMENT '上次登录时间',
  `last_login_ip` text NOT NULL COMMENT '上次登录ip',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gbox_admin`
--

LOCK TABLES `gbox_admin` WRITE;
/*!40000 ALTER TABLE `gbox_admin` DISABLE KEYS */;
INSERT INTO `gbox_admin` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e','2024-07-03 16:37:16','');
/*!40000 ALTER TABLE `gbox_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gbox_app`
--

DROP TABLE IF EXISTS `gbox_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gbox_app` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `name` text COMMENT '名称',
  `image` text COMMENT '图标',
  `version` decimal(24,2) DEFAULT NULL COMMENT '版本',
  `updateTime` datetime DEFAULT NULL COMMENT '更新时间',
  `introduce` text COMMENT '应用介绍',
  `appType` varchar(255) NOT NULL DEFAULT 'link' COMMENT '应用类型(self_sign,ent_sign,link)',
  `lock` int(11) NOT NULL DEFAULT '0' COMMENT '上锁(0未锁1锁)',
  `cateindex` int(11) DEFAULT NULL COMMENT '分类',
  `content` text COMMENT '下载地址,链接内容',
  `belongTo` int(11) NOT NULL DEFAULT '1' COMMENT '所属源',
  `state` int(11) DEFAULT '0' COMMENT '状态(0显示,1隐藏)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gbox_app`
--

LOCK TABLES `gbox_app` WRITE;
/*!40000 ALTER TABLE `gbox_app` DISABLE KEYS */;
/*!40000 ALTER TABLE `gbox_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gbox_block`
--

DROP TABLE IF EXISTS `gbox_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gbox_block` (
  `id` int(11) NOT NULL,
  `udid` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gbox_block`
--

LOCK TABLES `gbox_block` WRITE;
/*!40000 ALTER TABLE `gbox_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `gbox_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gbox_puk`
--

DROP TABLE IF EXISTS `gbox_puk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gbox_puk` (
  `id` int(11) NOT NULL COMMENT 'ID',
  `pukContent` text COMMENT '解锁码内容',
  `addTime` datetime NOT NULL COMMENT '添加日期',
  `useDate` date DEFAULT NULL COMMENT '使用日期',
  `useTime` datetime DEFAULT NULL COMMENT '使用详细时间',
  `expireTime` bigint(20) DEFAULT NULL COMMENT '到期时间(时间戳)',
  `userIP` text COMMENT '使用者IP',
  `udid` text COMMENT '使用者udid',
  `state` int(11) DEFAULT '0' COMMENT '状态(0未使用1使用)',
  `block` int(11) NOT NULL DEFAULT '0' COMMENT '是否禁用(0正常1禁用)',
  `belongTo` int(11) NOT NULL COMMENT '所属源',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gbox_puk`
--

LOCK TABLES `gbox_puk` WRITE;
/*!40000 ALTER TABLE `gbox_puk` DISABLE KEYS */;
/*!40000 ALTER TABLE `gbox_puk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gbox_source`
--

DROP TABLE IF EXISTS `gbox_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gbox_source` (
  `id` int(11) NOT NULL DEFAULT '1' COMMENT 'ID',
  `name` text COMMENT '源名称',
  `introduce` text COMMENT '源介绍',
  `linkTitle` text COMMENT '链接名称',
  `linkUrl` text COMMENT '链接地址',
  `author` text COMMENT '作者',
  `export` varchar(255) NOT NULL DEFAULT 'false' COMMENT '是否支持导出',
  `icon` text NOT NULL COMMENT '图标',
  `updateTime` datetime NOT NULL COMMENT '更新时间',
  `state` int(11) NOT NULL DEFAULT '0' COMMENT '状态(0正常1禁用)',
  `sort` text COMMENT '应用分类',
  `password` text COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gbox_source`
--

LOCK TABLES `gbox_source` WRITE;
/*!40000 ALTER TABLE `gbox_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `gbox_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'gbox'
--

--
-- Dumping routines for database 'gbox'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-03 16:39:45
