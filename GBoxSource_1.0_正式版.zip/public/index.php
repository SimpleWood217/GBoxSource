<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// [ 应用入口文件 ]

//检测是否安装
    if (PHP_VERSION_ID < 70000 || PHP_VERSION_ID >= 70300) {
        die('为了更好的使用程序,请设置PHP版本为7.0-7.2，请调整PHP版本，当前PHP版本：' . PHP_VERSION);
    }
    $lock_file = __DIR__ . '/install/install.lock';
    if (!file_exists($lock_file)) {
        exit("<script>window.location.href='/install'</script>");
    }
//绑定
    define('BIND_MODULE', 'index');
// 定义应用目录
    define('APP_PATH', __DIR__ . '/../application/');
// 加载框架引导文件
    require __DIR__ . '/../thinkphp/start.php';
